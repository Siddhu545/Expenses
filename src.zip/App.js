import React, {Component} from 'react';
import {View} from 'react-native';
import PackageList from './src/PackageList';
class App extends Component {
  render() {
    return (
      <View>
        <PackageList />
      </View>
    );
  }
}

export default App;
