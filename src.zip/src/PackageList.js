import React, { Component } from 'react';
import { View, FlatList } from 'react-native'
import PackageData from './Data/PackageData.json'
import Package from './AppsList/Package';
import * as ApkManager from 'react-native-apk-manager';
import { getAppstoreAppMetadata } from "react-native-appstore-version-checker"


class PackageList extends Component {

  render(){
    return(
         <View>
           <FlatList 
              data={PackageData}
              renderItem={({item}) => <Package props={item}/>}
              keyExtractor={item => item.packageID}
           />
         </View>
    )
  }
}

export default PackageList