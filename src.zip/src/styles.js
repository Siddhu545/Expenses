import React from'react'
import {StyleSheet} from 'react-native'

const styles = StyleSheet.create({
    container:{
      flex: 1,
      justifyContent: 'center',
      marginHorizontal: 16,
    },
    button:{
      width:10,
      marginVertical: 8,
    },
    separator: {
      marginVertical: 8,
      borderBottomColor: '#737373',
      borderBottomWidth: StyleSheet.hairlineWidth,
    }
  })

  export default styles
