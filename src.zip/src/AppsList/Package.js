import React, {Component} from 'react';
import {Text, AppState, Image, View, Button, Linking} from 'react-native';
import * as ApkManager from 'react-native-apk-manager';
import {getAppstoreAppMetadata} from 'react-native-appstore-version-checker';
import styles from '../styles';

class Package extends Component {
  state = {
    appState: AppState.currentState,
    title: 'Install',
    currentVersionData: '',
    latestVersionData: '',
    relaseDate: '',
  };
  componentDidMount() {
    this.appStateSubscription = AppState.addEventListener(
      'change',
      nextAppState => {
        if (
          this.state.appState.match(/inactive|background/) &&
          nextAppState === 'active'
        )
          this.setState({appState: nextAppState});
      },
    );
    ApkManager.isAppInstalled(this.props.props.packageName).then(data => {
      if (data == true) {
        this.setState({
          title: 'Open',
        });
      }
    });
    const cmpVersion = () => {
      ApkManager.getAppInformation(this.props.props.packageName).then(data => {
        this.setState({
          currentVersionData: this.state.currentVersionData.concat(
            data.versionName,
          ),
        });
      });
      getAppstoreAppMetadata(this.props.props.packageName).then(metadata => {
        this.setState({
          latestVersionData: this.state.latestVersionData.concat(
            metadata.version,
          ),
        });
      });
      let v1 = this.state.currentVersionData;
      let v2 = this.state.latestVersionData;

      let v1parts = v1.split('.');
      let v2parts = v2.split('.');

      v1parts = v1parts.map(Number);
      v2parts = v2parts.map(Number);

      for (var i = 0; i < v1parts.length; i++) {
        if (v1parts[i] === v2parts[i]) {
          continue;
        } else {
          return 1;
        }
      }
      return 0;
    };
    const result = cmpVersion();
    if (result !== 0) {
      this.setState({
        title: 'Update',
      });
    } else {
      console.log('Hey, All apps are updated');
    }
    getAppstoreAppMetadata(this.props.props.packageName).then(metadata => {
      let r1Date = new Date(metadata.currentVersionReleaseDate);
      let rDate = r1Date.getMonth() + '/' + r1Date.getFullYear();
      this.setState({
        relaseDate: this.state.relaseDate.concat(rDate),
      });
    });
  }
  componentWillUnmount() {
    this.appStateSubscription.remove();
  }
  render() {
    return (
      <View style={styles.container}>
        <Text style={{fontWeight: 'bold', fontSize: 20}}>
          {this.props.props.applicationName}
        </Text>
        <Text>Current Version : {this.state.currentVersionData}</Text>
        <Text>Latest Version : {this.state.latestVersionData}</Text>
        <Text>Relase Date : {this.state.relaseDate}</Text>
        <Image
          source={{uri: this.props.props.imageIcon}}
          style={{width: 100, height: 100, margin: 5}}
        />
        <Button
          style={styles.button}
          title={this.state.title}
          onPress={() => {
            if (this.state.title == 'Install') {
              Linking.openURL(this.props.props.storeUrl);
            } else {
              ApkManager.openApk(this.props.props.packageName);
            }
          }}
        />
      </View>
    );
  }
}
export default Package;
